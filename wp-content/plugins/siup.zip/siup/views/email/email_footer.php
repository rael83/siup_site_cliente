</div>
</td>
</tr>
</table>
<table align="center" role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="margin: auto;">
    <tr>
        <td valign="middle" class="bg_white footer">
            <img src="cid:footer" width="100%">
        </td>
    </tr>
</table>
</div>
</center>
</body>
</html>