var $ = jQuery.noConflict();
$(function() {
    
});